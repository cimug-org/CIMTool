 
= Validation Test Cases =

Test cases used for checking CIMTool's CIM/XML validation functionality can be found here:
http://files.cimtool.org/Validation-Cases-2008-02-15.zip

The archive contains:

 * a series of full and incremental CIM/XML files (*.xml)
 * two profiles (*.owl) with and without topology associations
 * the compatible version of the CIM (*.xmi)

Refer to TEST_RECORD.txt for a listing that details each each
test, the input files and the expected validation result.  Note that
each test is crafted to produce no errors or a single validation error
in isolation.  As a whole, the tests aim to cover all validation rules.

== HOWTO ==

The validation test cases are run automatically (via JUnit) during 
CIMTool development.  However, it is instructive to run these cases 
manually.

See http://cimtool.org/cimtool/wiki/GettingStarted and 
http://cimtool.org/cimtool/wiki/HowToValidateCPSM for general
instructions on driving CIMTool.  

To manually run the testcases:

=== Setup ===

1. Run eclipse and select the CIMTool perpective from the top right toolbar.

2. Create a new CIMTool project. Select File|New|CIMTool Project. 
Select the supplied CIM xmi file as the base schema. 

3. Import each of the two profiles (*.owl) into the project. Select 
File|Import|Import Profile

=== CIM/XML Validation ===

4. Switch to the validation perspective.

5. Import a model.  Select File|Import|Import Model or click the (+) button.  
Be sure to specify the correct profile.  
Consult TEST_RECORD.txt for this information.  
For example, the model base_case.xml goes with cpsm2007_no_topol.owl.

6. Click on the resulting diagnosic file in the Project View and browse the 
diagnostic reports in the Outline view.  For base_case.xml, there should be
no dignostics.  Other cases may generate a single diagnostic.  Consult 
TEST_RECORD.txt for the expected validation result.

7. You may repeat step 5 and import as many models as desired.

=== Incremental CIM/XML Validation ===

8. Consult TEST_RECORD.txt to find the names of incremental models, for 
example add_case.xml.   Before the incremental model can be imported, its
corresponding base model must be present in the project.   For add_case.xml
the base model is topology_case.xml.  Go back to step 5, if necessary, to
import the base model.

9. To import an incremental model select File|Import|Import Incremental Model 
or click the Incremental Import button. 

10. Click on the resulting diagnosic file in the Project View and browse the 
diagnostic reports in the Outline view. 


