/**
 * <p>This package contains classes that interface Saxon to the JDOM2 tree model.</p>
 */
package net.sf.saxon.option.jdom2;
