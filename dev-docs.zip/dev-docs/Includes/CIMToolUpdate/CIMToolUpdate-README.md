# CIMToolUpdate

> ⚠️ **This project is legacy/dormant and is not part of the active CIMTool
> build or packaging workflow.** It is retained in the repository as a
> reference for the original Eclipse update site deployment model. See
> [Current Status](#current-status--legacy--dormant) for details.

A project that was used to assemble and publish CIMTool distributions to an
Eclipse update site hosted at `http://files.cimtool.org`. It contained the
`site.xml` descriptor for the p2 update site and a shell script for packaging
and uploading platform-specific ZIP archives to Amazon S3.



## Current Status — Legacy / Dormant

CIMToolUpdate is **not actively used**. The update site it referenced
(`http://files.cimtool.org`) is defunct, and the current CIMTool distribution
model uses a standalone ZIP archive produced directly by the PDE product export
in `CIMToolProduct` — no update site or S3 upload step is involved.

This project has no `MANIFEST.MF`, no `build.properties`, and no Eclipse plugin
or feature structure. It is a plain Eclipse project (`.project` only) containing
a handful of files left over from the original deployment pipeline.

Additional indicators of dormancy:

- `site.xml` references `au.com.langdale.cimtoole.feature` at version `1.8.3.201008171439` — a build timestamp from 2010, far behind the current `2.3.0` release
- `makepackages.sh` uploads to `files.cimtool.org` via an `s3` command-line tool that is no longer configured
- The `Assembly/` directory referenced in `makepackages.sh` is excluded via `.gitignore` and does not exist in the repository



## Overview

When active, this project served as the deployment staging area for CIMTool
releases. The workflow was:

1. Eclipse PDE product export produced platform-specific exported directories under `Assembly/linux.*`, `Assembly/macosx.*`, `Assembly/win32.*`
2. `makepackages.sh package <version>` zipped each platform directory into a named archive (e.g. `CIMTool-2.3.0-win32.x86_64.zip`)
3. `makepackages.sh upload <version>` pushed the ZIPs to `files.cimtool.org` via Amazon S3

The `site.xml` registered the CIMTool feature in the Eclipse update site
category structure so users could install CIMTool directly from within Eclipse
via **Help > Install New Software**.



## Project Structure

```
CIMToolUpdate/
├── .project                ← Eclipse project descriptor (no plugin/feature structure)
├── .gitignore              ← Excludes the Assembly/ staging directory
├── site.xml                ← Eclipse update site descriptor (defunct — references 2010 build)
├── makepackages.sh         ← Shell script for packaging ZIPs and uploading to S3 (defunct)
└── plugin_customization.ini ← Single preference override (SHOW_PROGRESS_ON_STARTUP=true)
```

> **Note:** `plugin_customization.ini` in this project appears to be a leftover
> file with a single setting. It is not referenced by any active project and has
> no effect on the current build.



## Relationship to Other Projects

- **CIMToolFeature** — `site.xml` references the feature produced by `CIMToolFeature` (`au.com.langdale.cimtoole.feature`). Both projects are dormant and were part of the same legacy update site deployment pipeline.
- **CIMToolProduct** — the active replacement for this project's distribution role. The PDE product export in `CIMToolProduct` produces the ZIP archive directly without any separate packaging or upload step.



## Resurrecting Update Site Deployment

If Eclipse update site / p2 deployment is ever reinstated, the following would
be required:

1. Reinstate `CIMToolFeature` (set `useFeatures="true"` in `CIMTool.product`, update versions — see `CIMToolFeature-README.adoc` for details)
2. Update `site.xml` to reference the current feature version
3. Provision a new update site host and update the URL in `site.xml` and `CIMToolFeature/feature.xml`
4. Update `makepackages.sh` with the correct S3 bucket or hosting target
5. Create and populate the `Assembly/` staging directory as part of the post-export workflow
